public class Main {

	public static void main(String[] args) {
		Tree<String> t = new SimpleTree<String>();

		Node<String> question = new SimpleNode<String>("Does it have fur?");
		Node<String> answer1 = new SimpleNode<String>("Cat");
		Node<String> answer2 = new SimpleNode<String>("Fish");

		t.setRoot(question);
		t.insert(question, answer1);
		t.insert(question, answer2);

		SpeciesDetector<String> s = new SpeciesDetector<String>(t);
		System.out.println(s.getNextQuestion()); // Returns "Does it have fur?"
		
		System.out.println(s.submitAnswer(true));
	}

}
