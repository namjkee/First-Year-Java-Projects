
public class EmptyQueueException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -25586723978968324L;
	
}
