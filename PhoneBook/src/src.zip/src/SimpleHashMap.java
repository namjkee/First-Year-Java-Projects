import java.util.*;

class HashMapEntry {
	public Object key;
	public Object value;
	
	public HashMapEntry(Object key, Object value) {
		this.key = key;
		this.value = value;
	};
}

/* A simple hash map that doesn't handle conflicts - no linear probing or chaining */
public class SimpleHashMap implements HashMap {
	// instance variables
	private HashMapEntry[] items;
	private int numOfItems;
	
	// constructor
	public SimpleHashMap(int size) {
		this.items = new HashMapEntry[size];
		this.numOfItems = 0;
	}
	
	// helper method
	/* Hash-function, takes an object as input and returns a numerical representation of that object */
	private int hash(Object key) {
		return Math.abs(key.hashCode());
	}
	
	// access methods
	public int size() {
		return numOfItems;
	}

	public boolean isEmpty() {
		return (numOfItems == 0);
	}
	
	/* Compression Function - gets hash value by compressing hash function to fit array size*/
	public Object get(Object key) {
		int index = hash(key) % items.length;		// use modulo to compress into array size
		HashMapEntry entry = items[index];
		
		if (entry == null) return null;
		
		if (!entry.key.equals(key)) return null;
		
		return entry.value;
	}
	
	public List<Object> keys() {
		List<Object> keys = new ArrayList<Object>();
		
		for (HashMapEntry entry: items) {
			if (entry != null) {
				keys.add(entry.key);
			}
		}
		
		return keys;
	}

	public List<Object> values() {
		List<Object> values = new ArrayList<Object>();
		
		for (HashMapEntry entry: items) {
			if (entry != null) {
				values.add(entry.value);
			}
		}
		
		return values;
	}

	// update methods
	public void put(Object key, Object value) {
		int index = hash(key) % items.length;
		HashMapEntry hashKey = new HashMapEntry(key, value);
		
		if (items[index] == null) {
			items[index] = hashKey;
			numOfItems++;	// since the entry isn't occupied hence no collision
			return;
		}
		
		items[index] = hashKey;	// would overwrite current hash entry
	}

	public Object remove(Object key) {
		int index = hash(key) % items.length;
		HashMapEntry entry = items[index];
		
		if (entry == null) return null;
			
		else {
			items[index] = null;
			numOfItems--;
			return entry.value;
		}
	}

}
