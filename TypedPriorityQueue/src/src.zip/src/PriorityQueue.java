
public interface PriorityQueue<K extends Comparable<K>, V> {
	
	public void insert(Integer key, Object value);
	
	public Object removeMin();
	
	public Object min();
	
	public int size();
	
	public boolean isEmpty();
	
}
