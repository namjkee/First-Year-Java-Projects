package cpha3003;

import util.Coordinate;
import util.Ship;
import util.ShipPlacement;
import core.GameConfiguration;
import core.Player;

public class Player2 implements Player {

	@Override
	public Coordinate getNextShot(char[][] myBoard,
			char[][] myViewOfOpponentBoard) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ShipPlacement getShipPlacement(Ship ship, char[][] myBoard) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void notify(String message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newGame(String opponent, GameConfiguration config) {
		// TODO Auto-generated method stub
		
	}

}
