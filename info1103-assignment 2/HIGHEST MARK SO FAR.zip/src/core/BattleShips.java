package core;

import java.util.Collection;

import util.Coordinate;
import util.Ship;
import util.ShipPlacement;
import util.ShipPlacement.Direction;
import util.ShipPlacementException;
import core.GameConfiguration;

/**
 * Battleships class.
 * 
 * Fill in the methods.
 * They are ordered in the order you should code them in.
 * 
 * NOTES:
 * 	* Board states:
 * 		* empty spot is denoted by a 0 ( e.g. char a = 0; ). 
 * 			This is the default value for a char.
 * 		* ship segments that are not hit are denoted by a single lower case 
 * 			character that equals their ship handle.
 * 		* ship segments that are hit are denoted by a single UPPER case 
 * 			character that equals their ship handle.
 * 		* misses are denoted by a '.'
 * 
 * @author Clifford Phan
 *
 */
public class BattleShips implements Player {
	
	GameConfiguration config;
	Player player1;
	Player player2;
	char[][] player1Board;
	char[][] player2Board;
	
	char[][] player1EnemyView;
	char[][] player2EnemyView;
	
	/**
	 * #0 We advise you to implement this first
	 * 
	 * Constructor
	 * 
	 * Initialize all instance variables here.
	 * 
	 * @param config - the configuration for this player
	 * @param player1 - one player
	 * @param player2 - other player
	 */
	public BattleShips(GameConfiguration config, Player player1, Player player2) {

		this.config = config;
		this.player1 = player1;
		this.player2 = player2;
		
		int gridWidth = config.getGridWidth();
		int gridHeight = config.getGridHeight();
		
		player1Board = new char[gridHeight][gridWidth];
		player2Board = new char[gridHeight][gridWidth];
		
		/* Initializes own board aka player1 */
		for(int i = 0; i < gridHeight; i++) {
			for(int j = 0; j < gridWidth; j ++) {
				player1Board[i][j] = (char) 0;
			}
		}
		
		/* Initializes opponent board aka player2 */
		for(int i = 0; i < gridHeight; i++) {
			for(int j = 0; j < gridWidth; j++) {
				player2Board[i][j] = (char) 0;
			}
		}
		
		player1EnemyView = new char[gridHeight][gridWidth];
		player2EnemyView = new char[gridHeight][gridWidth];
		/* Initialize enemyView of both players with only 'H', '0' or '.' */
		for(int i = 0; i < gridHeight; i++) {
			for(int j = 0; j < gridWidth; j++) {
				player1EnemyView[i][j] = '0';
			}
		}
		
		for(int i = 0; i < gridHeight; i++) {
			for(int j = 0; j < gridWidth; j++) {
				player2EnemyView[i][j] = '0';
			}
		}
			
	}
	
	/**
	 * #1 (implement this next)
	 * 
	 * Function to check if the coordinate is valid. 
	 * 
	 * A coordinate is valid if and only if:
	 * 	* x value is within the board bounds (greater or equal to 0 and less 
	 * 		than the grid width)
	 * 	* y value is within the board bounds (greater or equal to 0 and less 
	 * 		than the grid height)
	 * 
	 * HINT: call this method to ensure the coordinate is valid before using it 
	 * in any calculations!
	 * 
	 * @param x - the x coordinate
	 * @param y - the y coordinate
	 * @return true - coordinate is valid
	 * @return false - coordinate is invalid
	 */
	protected boolean isValidCoordinate(int x, int y) {
		
		Coordinate coordinate = new Coordinate(x, y);
		x = coordinate.getX();
		y = coordinate.getY();
		
		int gridWidth = config.getGridWidth();
		int gridHeight = config.getGridHeight();
		
		/* Valid if within board bounds */
		if(x >= 0 && y >= 0 && x < gridWidth && y < gridHeight){
			return true;
		}
		
		/* Otherwise, invalid */
		return false;
	}
	
	/**
	 * #2
	 * 
	 * Function to check if the shot is valid.
	 * 
	 * A shot is valid if and only if:
	 * 	* it is within bounds
	 * 
	 * @param shot - the shot being taken
	 * @return true - shot is valid
	 * @return false - the shot is invalid
	 */
	protected boolean isValidShot(Coordinate shot) {

		int x = shot.getX();
		int y = shot.getY();
		
		/* If coordinate valid, then shot is valid */
		if(isValidCoordinate(x, y) == true) {
			return true;
		}
		
		/* Otherwise invalid shot */
		return false;
	}
	
	/**
	 * #3
	 * 
	 * Function to get the value of the cell on a specific player's board
	 * 
	 * @param player - the player whose board you are referring to 
	 * 	(0 for player 1, 1 for player 2)
	 * 
	 * @param x - the x coordinate
	 * @param y - the y coordinate
	 * 
	 * @return the character in the cell (-1 if the coordinates are invalid)
	 */
	protected char getCellState(int player, int x, int y) {

		Coordinate coordinate = new Coordinate(x,y);
		x = coordinate.getX();
		y = coordinate.getY();
	
		/* First step to check if cell state is invalid */
		if (isValidCoordinate(x, y) == false) {
			return (char) -1;
		}
		
		/* Otherwise valid */
		switch(player) {
		case 0:
			if (player1Board[y][x] == '.') {
				return '.';
			}
			
			for(char lowercase = 'a'; lowercase <= 'z'; lowercase++) {
				if(player1Board[y][x] == lowercase) {
					return lowercase;
				}
			}
			
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {
				if(player1Board[y][x] == uppercase) {
					return uppercase;
				}
			}
			
		case 1:
			if (player2Board[y][x] == '.') {
				return '.';
			}
			
			for(char lowercase = 'a'; lowercase <= 'z'; lowercase++) {
				if(player2Board[y][x] == lowercase) {
					return lowercase;
				}
			}
			
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {
				if(player2Board[y][x] == uppercase) {
					return uppercase;
				}
			}
		}

		/* If the cell states are none of the above, then it's correctly assumed empty */
		return (char) 0;
	}
		
	/**
	 * #4
	 * 
	 * Function to resolve a shot.
	 * 
	 * It must:
	 * 	* change the correct board value to the correct value.
	 * 	* send the correct message to the correct player.
	 * 
	 * Correct value changes:
	 * 	* If the character is a lower case character - make it upper case 
	 * 		(shot)
	 * 	* If the character is 0 - make it '.' (miss)
	 * 	* If the character is upper case or '.' - do nothing (miss)
	 * 
	 * Correct messages:
	 * 	* If the character is a lower case character - "HIT (x,y)" where x is 
	 * 		the x coordinate and y is the y coordinate
	 * 	* If the whole ship has been sunk - "SUNK 'A'" where 'A' is the ship 
	 * 		handle (don't include the ' marks)
	 * 	* If the character is 0 - "MISS (x,y)" where x is the x coordinate and 
	 * 		y is the y coordinate
	 * 	* If the character is upper case or '.' - do nothing (miss)
	 * 
	 * @param shot - the current shot
	 * @param player - the player SHOOTING
	 */
	protected void resolveShot(Coordinate shot, int player) {
			if(shot == null) {
				throw new NullPointerException();
			}

		int x = shot.getX();
		int y = shot.getY();
		
		int gridHeight = config.getGridHeight();
		int gridWidth = config.getGridWidth();
		
		switch(player) {
		case 0: /* Shot hit */
			for(char lowercase = 'a'; lowercase <= 'z'; lowercase++) {
				if (getCellState(1, x, y) == lowercase) {
					
					char ship = getCellState(1, x, y); // store specific ship to check if it sunk
					player2Board[y][x] = Character.toUpperCase(lowercase);
					player1EnemyView[y][x] = Character.toUpperCase(lowercase);
					player1.notify("HIT (" + x + "," + y + ")");
					
					/* Check if ship has sunk */
					outsideloop:
					for(int i = 0; i < gridHeight; i++) {
						for(int j = 0; j < gridWidth; j++) {
							if(player2Board[i][j] == ship) {
								break outsideloop;
							}
							/* When iterated to the last cell, without a ship, then ship has sunk */
							else if(player2Board[i][j] == player2Board[gridHeight - 1][gridWidth - 1]) {
								player1.notify("SUNK " + ship);
							}
						}
					}
					
				}
			}
			/* Shot miss */
			if(getCellState(1, x, y) == (char) 0) {
				player2Board[y][x] = '.';
				player1EnemyView[y][x] = '.';
				player1.notify("MISS (" + x + "," + y + ")");
			}
			/* Shot already fired there */
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {
				if(getCellState(1, x, y) == uppercase || getCellState(1, x, y) == '.') {
					//Do Nothing
				}
			}
			
		case 1: /* Shot hit */
			for(char lowercase = 'a'; lowercase <= 'z'; lowercase++) {
				if (getCellState(0, x, y) == lowercase) {
					
					char ship = getCellState(0, x, y); // store specific ship to check if it sunk
					player1Board[y][x] = Character.toUpperCase(lowercase);
					player2EnemyView[y][x] = Character.toUpperCase(lowercase);
					player2.notify("HIT (" + x + "," + y + ")");
					
					/* Check if ship has sunk */
					outsideloop:
					for(int i = 0; i < gridHeight; i++) {
						for(int j = 0; j < gridWidth; j++) {
							if(player1Board[i][j] == ship) {
								break outsideloop;
							}
							/* When iterated to the last cell, without a ship, then ship has sunk */
							else if(player1Board[i][j] == player1Board[gridHeight - 1][gridWidth - 1]) {
								player2.notify("SUNK " + ship);
							}
						}
					}
					
				}
			}
			/* Shot miss */
			if(getCellState(0, x, y) == (char) 0) {
				player1Board[y][x] = '.';
				player2EnemyView[y][x] = '.';
				player2.notify("MISS (" + x + "," + y + ")");
			}
			/* Shot already fired there */
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {
				if(getCellState(0, x, y) == uppercase || getCellState(0, x, y) == '.') {
					//Do Nothing
				}
			}
		} // end of switch
		
	}
	
	/**
	 * #5
	 * 
	 * Function to resolve a ship placement.
	 * 
	 * It must first check if a ship placement is valid, then place it if it 
	 * is valid.
	 * 
	 * The placement of a ship is valid if and only if:
	 * 	* the shipPlacement is not null
	 * 	* no square that the ship is going to occupy is outside the grid
	 * 	* no square that the ship is going to occupy is already occupied by 
	 * 		another ship
	 * 
	 * If a square of the ship is going to occupy a position that is already 
	 * occupied by another ship, the already placed ship will sink and the new 
	 * ship will not be placed.
	 * 
	 * If a ship is placed on top of multiple ships, they ALL sink.
	 * 
	 * @param shipPlacement - the ship placement (starting coordinate and 
	 * 			direction)
	 * @param ship - the ship being placed
	 * @param player - the player placing the ship
	 * @throws ShipPlacementException - thrown when there is a placement problem
	 * @see ShipPlacementException
	 */
	protected void placeShip(Ship ship, ShipPlacement shipPlacement, int player) 
			throws ShipPlacementException {
		
		Direction direction = shipPlacement.getDirection();
		Coordinate beginning = shipPlacement.getBeginning();
		
		int x = beginning.getX();
		int y = beginning.getY();
		
		char shipHandle = ship.getShipHandle();
		int shipLength = ship.getShipLength();
			
		/* Exception when ship placed outside of grid */	
		if(isValidCoordinate(x, y) == false){
			throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
		}
		
		/* Condition to place the ship on "empty space" only */
		if(shipPlacement != null && isValidCoordinate(x, y) == true) {
			if(player == 0) {
				
				/* Places ship with respect to direction and throws exception if outside grid */
				switch(direction){
				case NORTH: 
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x, y + i) == true) {
							player1Board[y + i][x] = shipHandle;
						}
						else if(isValidCoordinate(x, y + i) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case EAST:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x + i, y) == true) {
							player1Board[y][x + i] = shipHandle;
						}
						else if(isValidCoordinate(x + i, y) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case SOUTH:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x, y - i) == true) {
							player1Board[y - i][x] = shipHandle; 
						}
						else if(isValidCoordinate(x, y - i) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case WEST:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x - i, y) == true) {
							player1Board[y][x - i] = shipHandle;
						}
						else if(isValidCoordinate(x - i, y) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				} // end of player 1 switch
				
			}
			
			else if(player == 1) {
				
				/* Places ship with respect to direction and throws exception if outside grid */
				switch(direction){
				case NORTH: 
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x, y + i) == true) {
							player2Board[y + i][x] = shipHandle;
						}
						else if(isValidCoordinate(x, y + i) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case EAST:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x + i, y) == true) {
							player2Board[y][x + i] = shipHandle;
						}
						else if(isValidCoordinate(x + i, y) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case SOUTH:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x, y - i) == true) {
							player2Board[y - i][x] = shipHandle; 
						}
						else if(isValidCoordinate(x, y - i) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				case WEST:
					for(int i = 0; i < shipLength; i++) {
						if(isValidCoordinate(x - i, y) == true) {
							player2Board[y][x - i] = shipHandle;
						}
						else if(isValidCoordinate(x - i, y) == false) {
							throw new ShipPlacementException("SHIP " + shipHandle + " RAN AGROUND");
						}
					}
					break;
				} // end of player 2 switch
				
			}//end of outer if statement
				
		}
		/* Occupied ship will sink and new ship won'be placed, hence cell is empty */
		else if(getCellState(0, x, y) != (char) 0) { // In Placement Phase, cells are only 'a' or /0
			
			/* Assigns occupied ship's handles */
			char ch = player1Board[y][x];
			/* Iterates through entire grid to sink these particular ship handles */
			for(int i = 0; i < config.getGridHeight(); i++) {
				for(int j = 0; j < config.getGridWidth(); j++) {
					if(player1Board[i][j] == ch) {
						player1Board[i][j] = (char) 0;
					}
				}
			}
			/* After ship sinks, needs to throw exception */
			throw new ShipPlacementException("SHIP " + shipHandle + " RAN OVER SHIP " + player1Board[y][x]);
			
		}
		/* Similar for player2's placement */
		else if(getCellState(1, x, y) != (char) 0) {
			
			char ch = player2Board[y][x];
			
			for(int i = 0; i < config.getGridHeight(); i++) {
				for(int j = 0; j < config.getGridWidth(); j++) {
					if(player2Board[i][j] == ch) {
						player2Board[i][j] = (char) 0;
					}
				}
			}
			
			throw new ShipPlacementException("SHIP " + shipHandle + " RAN OVER SHIP " + player2Board[y][x]);
			
		}
		
	}
	
	/**
	 * #6
	 * 
	 * Function to get the enemy view of a player's board
	 * 
	 * You generate the view based on these rules:
	 * 	* if the value is upper case, show 'H'
	 * 	* if the value is lower case, show 0
	 * 	* otherwise - the true value
	 * 
	 * @param player - the player whose board you are going to view
	 * @return the view (contains only 'H', '.' and 0
	 */
	protected char[][] getEnemyView(int player) {
		
		switch(player) {
		
		case 0: /* Checking upper and lowercase in grid to convert */
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {	
				
			char lowercase = Character.toLowerCase(uppercase);
			
			/* Checks each row to assign new values */
			for(int i = 0; i < config.getGridHeight(); i++) {
				for(int j = 0; j < config.getGridWidth(); j++) {
					if(player1EnemyView[i][j] == uppercase) {
						player1EnemyView[i][j] = 'H';
					}
					else if(player1EnemyView[i][j] == lowercase) {
						player1EnemyView[i][j] = '0';
					}
				}
			}
			
		}
		return player1EnemyView;
		
		case 1: /* Similar to above */
			for(char uppercase = 'A'; uppercase <= 'Z'; uppercase++) {	
				
			char lowercase = Character.toLowerCase(uppercase);
			
			/* Checks each row to assign new values */
			for(int i = 0; i < config.getGridHeight(); i++) {
				for(int j = 0; j < config.getGridWidth(); j++) {
					if(player2EnemyView[i][j] == uppercase) {
						player2EnemyView[i][j] = 'H';
					}
					else if(player2EnemyView[i][j] == lowercase) {
						player2EnemyView[i][j] = '0';
					}
				}
			}
			
		}
		return player2EnemyView;
		
		} // end of switch
		return null;
	}
	
	/**
	 * #7
	 * 
	 * Function to start and run the game.
	 * 
	 * @return the player that has won ( null if it was a draw )
	 */
	public Player run() {
		
		String playerone = player1.getClass().getCanonicalName();
		String playertwo = player2.getClass().getCanonicalName();
		
		/* Introduce players at start of match */
		player1.newGame(playertwo, config);
		player2.newGame(playerone, config);
		
		/* Allocates ships to players to place - Placement Phase */
		Collection<Ship> ships = config.getShips();
		for(Ship ship : ships) {
			ShipPlacement player1Placement = player1.getShipPlacement(ship, player1Board);
			try {
				placeShip(ship, player1Placement, 0);
			} catch (ShipPlacementException e) {
				e.getMessage();
			}
			
			ShipPlacement player2Placement = player2.getShipPlacement(ship, player2Board);
			try {
				placeShip(ship, player2Placement, 1);
			} catch (ShipPlacementException e) {
				e.getMessage();
			}
		}
		
		int gridHeight = config.getGridHeight();
		int gridWidth = config.getGridWidth();
		
		/* Resolve both player's next shots - Shooting Phase */
		while(true){ // Unlimited turns until a player is defeated
		Coordinate player1Shot = player1.getNextShot(player1Board, player2Board);
		Coordinate player2Shot = player2.getNextShot(player2Board, player1Board);
		
		resolveShot(player1Shot, 0);
		getEnemyView(0);
		resolveShot(player2Shot, 1);
		getEnemyView(1);
		
		Player p1Win = null;
		Player p2Win = null;
		
		/* Checks if a player is defeated */
		outerloop:
			for(char ship = 'a'; ship <= 'z'; ship++) {
				for(int i = 0; i < gridHeight; i++) {
					for(int j = 0; j < gridWidth; j++) {
						
						if(player1Board[i][j] == ship) {
							break outerloop;
						}
						/* When iterated to the last cell without ship, then player2 wins  */
						else if(player1Board[i][j] == player1Board[gridHeight - 1][gridWidth - 1]) {
							p2Win = player2;
/*							player1.notify("LOSE");
							player2.notify("WIN");
							return player2;	*/
						}
						if(player2Board[i][j] == ship) {
							break outerloop;
						}
						/* Similar to above but for player1 */
						else if(player2Board[i][j] == player2Board[gridHeight - 1][gridWidth - 1]) {
							p1Win = player1;		
/*							player1.notify("WIN");
							player2.notify("LOSE");
							return player1;	*/
						}
	
						/* Check if any player has won */
						if(p1Win == player1 || p2Win == player2) {
							if(p1Win == player1 && p2Win == player2) {
								player1.notify("DRAW");
								player2.notify("DRAW");
								return null;
							}
							else if(p1Win == player1 && p2Win != player2) {
								player1.notify("WIN");
								player2.notify("LOSE");
								return player1;
							}
							else if(p1Win != player1 && p2Win == player2) {
								player1.notify("LOSE");
								player2.notify("WIN");
								return player2;
							}
						}
						
					}
				}
		}
		
		}// end of while true loop 
	
	}

	@Override
	public Coordinate getNextShot(char[][] myBoard,
			char[][] myViewOfOpponentBoard) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ShipPlacement getShipPlacement(Ship ship, char[][] myBoard) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void notify(String message) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newGame(String opponent, GameConfiguration config) {
		// TODO Auto-generated method stub
		
	}
	
}