
public class EmptyStackException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 244490188855298564L;
	
}
